
#ifndef AVRAGE_HPP_
#define AVRAGE_HPP_

double avg(double*);

#endif /* AVRAGE_HPP_ */