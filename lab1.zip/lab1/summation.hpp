#ifndef SUMMATION_HPP_
#define SUMMATION_HPP_

double sum(double*);

#endif /* SUMMATION_HPP_ */