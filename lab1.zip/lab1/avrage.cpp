#include "avrage.hpp"
#include "summation.hpp"

double avg(double *array){
    return sum(array)/10;
}